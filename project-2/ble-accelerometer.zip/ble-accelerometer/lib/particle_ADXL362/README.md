# ADXL362
Library for the ADXL362 accelerometer factored out of the internet button library
